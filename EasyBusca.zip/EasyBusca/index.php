<?php

header('Location: listar/');

?>
