<?php

define('HOST', 'localhost:3306');
define('USUARIO', 'u408165698_moh4mm3d');
define('SENHA', 'Ac2017@net');
define('DB', 'u408165698_moh4mm3d');


//difini os usuarios padroes do admin

$usuarioPardraodoAdmin = "M0h4mm3d_Salah";
$chavePadraodoAdmin = "472478";


if (mysqli_connect(HOST, USUARIO, SENHA, DB) !== 1){
	define('HOST1', 'localhost:3306');
	define('USUARIO1', 'u408165698_moh4mm3d');
	define('SENHA1', 'Ac2017@net');
	define('DB1', 'u408165698_moh4mm3d');

	$conexaocreate = mysqli_connect(HOST1, USUARIO1, SENHA1, DB1);
	$exec = mysqli_query($conexaocreate , "CREATE DATABASE u408165698_moh4mm3d");


}



$conexao = mysqli_connect(HOST, USUARIO, SENHA, DB);

try {
	$resUsers = mysqli_query($conexao , "SELECT * FROM usuarios");

    $errorUsers = mysqli_fetch_assoc($resUsers);
} catch (Exception $e) {
	mysqli_query($conexao , "CREATE TABLE usuarios (
		id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		usuario VARCHAR(200) NOT NULL,
		saldo INT(200) NOT NULL
	)");
}catch (Throwable $e) {
	mysqli_query($conexao , "CREATE TABLE usuarios (
		id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		usuario VARCHAR(200) NOT NULL,
		saldo INT(200) NOT NULL
	)");
}



try {
	$resAdmin = mysqli_query($conexao , "SELECT * FROM admin");

    $erroradmin = mysqli_fetch_assoc($resAdmin);

} catch (Exception $e) {
	mysqli_query($conexao , "CREATE TABLE admin (
		id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		user VARCHAR(200) NOT NULL,
		chave VARCHAR(200) NOT NULL
	)");
}catch (Throwable $e) {
	mysqli_query($conexao , "CREATE TABLE admin (
		id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		user VARCHAR(200) NOT NULL,
		chave VARCHAR(200) NOT NULL
	)");

	mysqli_query($conexao , "INSERT INTO admin (user , chave) VALUES ( '$usuarioPardraodoAdmin' , '".md5($chavePadraodoAdmin)."')");
}



?>