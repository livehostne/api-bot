<?php

    $sql = "select * from usuarios where usuario = $chat_id";
    $result = mysqli_query($conexao, $sql);
    $row = mysqli_fetch_assoc($result);
    $creditos = $row['saldo'];
    	
        if ($type == "supergroup"){
$tipo = "GRUPO";
}else{
$tipo = "PRIVADO";
};

Sendx9($chat_id,$message_id, "
Mensagem Recebida

De : $firstname
Chat id : $chat_id
Creditos : $creditos
Usuario : @$username
Tipo Chat : $tipo

Mensagem : $message ");

?>